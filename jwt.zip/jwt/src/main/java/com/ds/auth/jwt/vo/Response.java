package com.ds.auth.jwt.vo;

import lombok.Data;

@Data
public class Response {
	private String responseObject;
	private String responseMsg;
	private String responseCode;

}
