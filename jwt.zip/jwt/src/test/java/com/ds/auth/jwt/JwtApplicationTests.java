package com.ds.auth.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = JwtApplicationTests.class)
class JwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
